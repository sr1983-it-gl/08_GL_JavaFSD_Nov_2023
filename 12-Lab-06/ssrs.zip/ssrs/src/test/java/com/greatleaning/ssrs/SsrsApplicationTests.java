package com.greatleaning.ssrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
