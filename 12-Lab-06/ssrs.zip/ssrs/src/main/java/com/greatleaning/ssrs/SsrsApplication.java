package com.greatleaning.ssrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsrsApplication.class, args);
	}

}
