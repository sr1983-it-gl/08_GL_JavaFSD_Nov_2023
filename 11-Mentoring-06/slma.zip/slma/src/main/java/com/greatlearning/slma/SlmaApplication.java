package com.greatlearning.slma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlmaApplication.class, args);
	}

}
