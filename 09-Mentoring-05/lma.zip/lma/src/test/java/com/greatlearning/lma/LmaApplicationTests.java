package com.greatlearning.lma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
