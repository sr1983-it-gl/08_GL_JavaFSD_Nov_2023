package com.greatlearning.lma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmaApplication.class, args);
	}

}
